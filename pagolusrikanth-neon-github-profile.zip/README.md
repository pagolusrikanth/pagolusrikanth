<div align="center">

<img src="./assets/header.svg" width="100%" alt="P Srikanth neon developer header"/>

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=700&size=22&duration=2500&pause=700&color=FF4FD8&center=true&vCenter=true&width=850&lines=Full+Stack+Developer+%F0%9F%92%BB;AI+%26+Machine+Learning+Explorer+%F0%9F%A4%96;DevOps+%26+Cloud+Learner+%E2%98%81%EF%B8%8F;Code+%E2%80%A2+Build+%E2%80%A2+Learn+%E2%80%A2+Repeat+%F0%9F%9A%80" alt="Typing animation"/>

<br/>

<img src="https://komarev.com/ghpvc/?username=pagolusrikanth&label=PROFILE%20VIEWS&color=ff2bd6&style=for-the-badge" alt="Profile views"/>
<img src="https://img.shields.io/github/followers/pagolusrikanth?label=FOLLOWERS&style=for-the-badge&color=7c3aed" alt="Followers"/>

</div>

## 💜 About Me

```yaml
name: P Srikanth
github: pagolusrikanth
education:
  - MCA
  - M.Tech
focus:
  - Full Stack Development
  - Artificial Intelligence & Machine Learning
  - DevOps & Cloud
currently_learning:
  - Linux
  - Docker
  - AWS
  - CI/CD
motto: "Code • Build • Learn • Repeat 🚀"
```

<div align="center">
<img src="./assets/developer-card.svg" width="92%" alt="Developer card"/>
</div>

## ⚡ Tech Arsenal

<div align="center">

<img src="https://skillicons.dev/icons?i=java,python,php,js,html,css,mysql,git,github,linux,docker,aws,vscode,androidstudio&perline=7" alt="Tech stack"/>

</div>

## 🚀 Featured Builds

| Project | What it does | Stack |
|---|---|---|
| 💳 **Credit Card Approval Prediction** | ML-powered credit approval prediction | Python · Flask · Scikit-learn |
| 📲 **Smart Attendance System** | Attendance management and reporting | PHP · MySQL · JavaScript |
| 🖥️ **Lab Manager** | Lab systems management application | Java · Android |
| 🤖 **ML Projects** | Practical machine-learning experiments | Python · ML |
| 🧠 **NLP Projects** | Natural-language-processing experiments | Python · NLP |

## 📊 GitHub Command Center

<div align="center">

<img height="170" src="https://github-readme-stats.vercel.app/api?username=pagolusrikanth&show_icons=true&theme=radical&hide_border=true&rank_icon=github" alt="GitHub stats"/>
<img height="170" src="https://github-readme-stats.vercel.app/api/top-langs/?username=pagolusrikanth&layout=compact&theme=radical&hide_border=true" alt="Top languages"/>

<br/><br/>

<img src="https://streak-stats.demolab.com?user=pagolusrikanth&theme=radical&hide_border=true" alt="GitHub streak"/>

<br/><br/>

<img width="95%" src="https://github-readme-activity-graph.vercel.app/graph?username=pagolusrikanth&theme=react-dark&hide_border=true&area=true" alt="Contribution graph"/>

</div>

## 🐍 Contribution Snake

<div align="center">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/pagolusrikanth/pagolusrikanth/output/github-snake-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/pagolusrikanth/pagolusrikanth/output/github-snake.svg">
  <img alt="GitHub contribution snake" src="https://raw.githubusercontent.com/pagolusrikanth/pagolusrikanth/output/github-snake.svg">
</picture>
</div>

## 🏆 Achievements

<div align="center">
<img src="https://github-profile-trophy.vercel.app/?username=pagolusrikanth&theme=radical&no-frame=true&no-bg=true&margin-w=8&row=1" alt="GitHub trophies"/>
</div>

## 🌐 Connect

<div align="center">

<a href="https://github.com/pagolusrikanth"><img src="https://img.shields.io/badge/GitHub-pagolusrikanth-181717?style=for-the-badge&logo=github&logoColor=white"/></a>

<br/><br/>

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=18&duration=2200&pause=700&color=00E7FF&center=true&vCenter=true&width=700&lines=Thanks+for+entering+my+digital+universe+%F0%9F%92%9C;Keep+learning.+Keep+building.+%F0%9F%9A%80;See+you+in+the+next+commit!" alt="Footer typing"/>

<img src="./assets/footer.svg" width="100%" alt="Neon footer"/>

</div>
